from flask import Flask, render_template, request
import joblib

app = Flask(__name__)

# Load your trained model
model = joblib.load('model.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get input values from the form
        src = float(request.form['src_bytes'])
        dst = float(request.form['dst_bytes'])
        count = float(request.form['count'])

        # Make prediction using the model
        prediction = model.predict([[src, dst, count]])

        # Convert numerical prediction to readable output
        result = "Normal" if prediction[0] == 0 else "Attack"

        return render_template('index.html', prediction=result)
    
    except Exception as e:
        return render_template('index.html', prediction=f"Error: {e}")

if __name__ == '__main__':
    app.run(debug=True)
